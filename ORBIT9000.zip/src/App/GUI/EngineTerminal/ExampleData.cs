﻿namespace Orbit9000.EngineTerminal
{
    public class ExampleData
    {
        public SettingsData Frame1 { get; set; }
        public EngineData Frame2 { get; set; }
    }

}