﻿namespace ORBIT9000.Engine.Configuration.Raw
{
    internal class RawOrbitEngineConfig
    {
        public required RawOrbitEngine OrbitEngine { get; set; }
    }
}