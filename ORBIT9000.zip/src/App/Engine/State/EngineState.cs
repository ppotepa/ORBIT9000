﻿namespace ORBIT9000.Engine.State
{
    public class EngineState
    {
        public OrbitEngine Engine { get; internal set; }
    }
}