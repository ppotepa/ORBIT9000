﻿namespace ORBIT9000.Core.Configuration
{
    public class OrbitAppSettings
    {
        public required Orbit Orbit { get; set; }
    }

    public class Orbit
    {
    }
}
