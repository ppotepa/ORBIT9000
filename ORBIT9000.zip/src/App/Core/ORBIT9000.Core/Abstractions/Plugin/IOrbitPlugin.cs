﻿using Microsoft.Extensions.DependencyInjection;

namespace ORBIT9000.Core.Abstractions.Plugin
{
    public interface IOrbitPlugin
    {        
        void Run();
    }
}
