﻿namespace ORBIT9000.Core.Abstractions.Result
{
    public interface IResult
    {
    }
}