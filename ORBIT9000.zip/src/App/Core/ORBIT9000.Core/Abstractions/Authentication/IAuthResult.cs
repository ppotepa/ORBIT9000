﻿namespace ORBIT9000.Core.Abstractions.Authentication
{

    public interface IAuthResult
    {
    }
}