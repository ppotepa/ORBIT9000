﻿namespace ORBIT9000.Core.Abstractions.Providers.Data
{
    public interface IResult
    {
    }
}