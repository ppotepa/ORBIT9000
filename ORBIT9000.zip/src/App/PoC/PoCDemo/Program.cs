﻿using ORBIT9000.Engine;

namespace ORBIT9000.PoCDemo
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            OrbitEngine engine = new OrbitEngine();
            engine.Start();
       }
    }
}