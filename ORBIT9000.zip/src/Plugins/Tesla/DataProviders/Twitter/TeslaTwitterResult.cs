﻿using ORBIT9000.Core.Abstractions.Result;

namespace ORBIT9000.Plugins.Tesla.Scrapers.Twitter
{
    public class TeslaTwitterResult : IResult
    {
    }
}