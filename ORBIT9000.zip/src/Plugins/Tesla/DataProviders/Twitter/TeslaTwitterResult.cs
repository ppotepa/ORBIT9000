﻿using ORBIT9000.Core.Abstractions.Result;

namespace ORBIT9000.Plugins.Tesla.DataProviders.Twitter
{
    public class TeslaTwitterResult : IResult
    {
    }
}