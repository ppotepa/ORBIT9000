﻿Console.WriteLine("PreBuild Helper will build all plugins in this solution.");
